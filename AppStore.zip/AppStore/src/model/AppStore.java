package model;

public class AppStore {

	private String country;
	private int maxApps;
	private App[] app;
	private int numberOfApps;
	
	public AppStore(String country, int maxApps) {
		
		this.country = country;
		this.maxApps = maxApps;
		this.app = new App[this.maxApps];
		
		for(int i = 0; i < this.maxApps; i++) {
			
			this.app[i] = new App();
			
		}	
		
		//default value, stated it for practice
		this.numberOfApps = 0;
				
		
	}
	
	public String getBranch() {
		
		return this.country;
		
	}
	
	public void setBranch(String country) {
		
		this.country = country;
		
	}
	
	public App getApp(String appName) {
		
		int indexOfApp = -1;
		
		for(int i = 0; i < this.maxApps; i++) {
			
			if(this.app[i].getName() == appName) {
				
				indexOfApp = i;
				break;
				
			}
			
		}
		
		if(indexOfApp != -1) {
			
			return app[indexOfApp];
			
		}else {
			
			return null;
			
		}
		
	}
	
	public String[] getStableApps(int updateCount) { // updateCount means there are at least this many updates

		int count = 0; // number of products satisfying the search criteria
		int[] indices = new int[this.maxApps]; // indices of entry entry objects, in the entries array, that satisfy the search criteria.

		
		for(int i = 0; i < this.maxApps; i++) {
			
			if(this.app[i].getUpdateHistory().length >= updateCount) {
				
				indices[count] = i;
				count++;
				
			}
						
		}
		
		String[] sns = new String[count];
		
		for(int i = 0; i < count; i++) {
			
			sns[i] = this.app[indices[i]].getName() + " (" + this.app[indices[i]].getNumberOfVersions() +
					" versions; Current Version: " + this.app[indices[i]].getVersionInfo(this.app[indices[i]].getCurrentVersion()) +
					")"; 
			
		}
		
		return sns;

	}
	
	public void addApp(App app) {
		
		this.numberOfApps++;
		this.app[this.numberOfApps - 1] = app;	
		
		
		
	}

}

