package model;

public class Account {
	
	private String accountName;
	private AppStore appStoreLocation;
	private App[] appsInAccount;
	private String status;
	private String status1;
	private boolean pass;
	private String tempApp;
	private String country;
	private String[] namesofDownloadedApps;
	private int numberOfDownloadedApps;
	private App[] objectsOfDownloadedApps;
	private int rating;

	public Account(String accountName, AppStore appStoreLocation) {
		
		this.accountName = accountName;
		this.appStoreLocation = appStoreLocation;
		this.appsInAccount = new App[3];
		
		//default values, stated them for practice
		this.status = "";
		this.status1 = "";
		this.tempApp = "";
		this.country = "";
		this.rating = 0;
		this.numberOfDownloadedApps = 0;
		this.pass = false;
		
		for(int i = 0; i < 3; i++) {
			
			this.appsInAccount[i] = new App();
						
		}
		
	}
	
	public String[] getNamesOfDownloadedApps() {
		
		int count = 0;

		for(int i = 0; i < this.numberOfDownloadedApps; i++) {

			if(appsInAccount[i] != null) {

				count++;
				
			}
			
		}
		
		this.namesofDownloadedApps = new String[this.numberOfDownloadedApps];
		
		for(int i = 0; i < count; i++) {
			
			this.namesofDownloadedApps[i] = this.appsInAccount[i].getName();
			
		}
		
			return this.namesofDownloadedApps;
				
	}
	
	public App[] getObjectsOfDownloadedApps() {
		
		objectsOfDownloadedApps = new App[this.numberOfDownloadedApps];
		
		for(int i = 0; i < this.numberOfDownloadedApps; i++) {
			
			objectsOfDownloadedApps[i] = this.appsInAccount[i];

		}
			
		return objectsOfDownloadedApps;

	}
	
	public void uninstall(String appName) {
		
		int a = -1;
		
		for(int i = 0; i < this.appsInAccount.length; i++) {
			
			if(this.appsInAccount[i].getName() == appName) {
				
				a = 0;
				this.appsInAccount[i] = null;
				this.pass = true;
				this.numberOfDownloadedApps--;
				
				
				/*
				 * These two if statements are used to shift all the values
				 * over so that there are no nulls in between the values
				 * 
				 */
				
				/*
				 * The first if statement is called when the null is in the first cell:
				 * [ null, x , x ]
				 * It moves all of the values over and makes the array become:
				 * [ x , x , null ]
				 */
				if(this.appsInAccount[0] == null) {
					
					this.appsInAccount[0] = this.appsInAccount[1];
					this.appsInAccount[1] = this.appsInAccount[2];
					this.appsInAccount[2] = null;
					
				}
					
				/*
				 * The second if statement is called when the null is in the middle cell:
				 * [ x, null , x ]
				 * It moves third value over and makes the array become:
				 * [ x , x , null ]
				 */ 
				if(this.appsInAccount[1] == null) {
					
					this.appsInAccount[1] = this.appsInAccount[2];
					
				}
				
				break;
				
			}
			
		}
		
		if(a == -1) {
			
			this.pass = false;
			
		}
		
		status = "uninstall";
		this.tempApp = appName;
		
	}
	
	public void download(String appName) {
		
		App app1 = appStoreLocation.getApp(appName);
		
		for(int i = 0; i < 3; i++) {
			
			if(appsInAccount[i] == appStoreLocation.getApp(appName)) {
				
				this.pass = false;
				status = "install";
				status1 = "fail";
				this.tempApp = appName;
				return;
				
			}
				
		}
		
		if(this.numberOfDownloadedApps <= 3) {
			
			appsInAccount[this.numberOfDownloadedApps] = app1;
			this.pass = true;
			this.numberOfDownloadedApps++;
		
		}else {
			
			this.pass = false;
			
		}
		
		status = "install";
		this.tempApp = appName;
			
	}
	
	
	public void submitRating(String appName, int rating) {
		
		int a = -1;
		
		for(int i = 0; i < appsInAccount.length; i++) {
			
			if(appsInAccount[i].getName() == appName) {
				
				a = 0;
				appsInAccount[i].submitRating(rating);
				this.rating = rating;
				this.pass = true;
				this.tempApp = appName;
				break;
				
			}
			
		}
		
		if(a == -1) {
			
			this.tempApp = appName;
			this.pass = false;
			
		}
		
		status = "submit";
		
	}
	
	public void switchStore(AppStore appStore) {
		
		this.country = appStore.getBranch();
		
		status = "switch";
		
	}
	
	
	public String toString() {
		
		String s = "";
		
		if(this.status == "uninstall") {
			
			if(this.pass == false) {
				
				s += "Error: " + this.tempApp + " has not been downloaded for " + this.accountName + ".";
				
			}
			
			if(this.pass == true) {
				
				s += this.tempApp + " is successfully uninstalled for " + this.accountName + ".";
				
				
			}
			
		}else if(this.status == "submit") {
			
			if(this.pass == false) {
				
				s += "Error: " + this.tempApp + " is not a downloaded app for " + this.accountName + ".";
				
			}
			
			if(this.pass == true) {
				
				s+= "Rating score " + this.rating + " of " + this.accountName + 
						" is successfully submitted for " + this.tempApp + ".";

			}
			
			
		}else if(this.status == "install") {
			
			if(this.pass == true) {
				
				s += this.tempApp + " is successfully downloaded for " + this.accountName + ".";
				
			}
			
			if(status1 == "fail") {
				
				s += "Error: " + this.tempApp + " has already been downloaded for " + this.accountName + ".";
				
			}
			
		}else if(this.status == "switch") {
			
			s += "Account for " + this.accountName + " is now linked to the " + this.country + " store.";
		
		}else {
			
			s += "An account linked to the " + this.appStoreLocation.getBranch() + 
				" store is created for " + this.accountName + ".";}
		
		return s;
		
	}

}
