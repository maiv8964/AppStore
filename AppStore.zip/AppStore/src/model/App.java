package model;



public class App {
		
	private String name;
	private int maxRating;
	private String versionInfo;
	private Log[] logs;
	private int[] ratings;

	private int numberOfVersions;
	private int sum;
	private double avg;
	private String avgString;
	
	private int rating1;
	private int rating2;
	private int rating3;
	private int rating4;
	private int rating5;
	private int numberOfRatings;
	
	public App(String name, int maxRatings) {

		logs = new Log[20];
		
		for(int i = 0; i < 20; i++) {
			
			logs[i] = new Log();
			
		}
		
		this.numberOfVersions = 0;
		this.versionInfo = "n/a";
		this.name = name;
		this.maxRating = maxRatings;
		this.ratings = new int[this.maxRating];
		
		//default values, stated them for practice
		this.sum = 0;
		this.rating1 = 0;
		this.rating2 = 0;
		this.rating3 = 0;
		this.rating4 = 0;
		this.rating5 = 0;
		this.numberOfRatings = 0;
		this.avg = 0.0;
		
		for(int i = 0; i < this.maxRating; i++){
			
			this.ratings[i] = -1;
			
		}
		
	}
	
	public App() {
		
		logs = new Log[20];
		
		for(int i = 0; i < 20; i++) {
			
			logs[i] = new Log();
			
		}
		
	}
	

	public String getName() {
		
		return name;
		
	}

	public void setName(String name) {
		
		this.name = name;
		
	}
	
	public Log getVersionInfo(String version) {
		
		int index = -1;
		
		for(int i = 0; i < 20; i++) {
			
			if(logs[i].getVersion() == version) {
				
				index = i;
				break;
				
			}
			
		}
		
		if(index != -1) {
			
			return logs[index];
			
		}else {
			
			return null;
			
		}
		
	}
	
	public String getCurrentVersion() {
		
		return this.versionInfo;
		
	}

	public int getNumberOfRatings() {
		
		return maxRating;
		
	}
	
	public Log[] getUpdateHistory() {
		
		Log[] lsize = new Log[0];
		
		for(int i = 0; i < 20; i++) {
			
			if(this.logs[i].getNewestUpdate() == "n/a") {
				
				lsize = new Log[i];
				break;
				
			}
			
		}
		
		for(int i = 0; i < lsize.length; i++) {
			
			lsize[i] = logs[i];
			
		}
		
		return lsize;
		
	}	
	
	public String getWhatIsNew() {
		
		for(int i = 0; i < this.logs.length; i++) {
			
			if(this.logs[i].getNewestUpdate() == "n/a" && i == 0) {
				
				return "n/a";
				
			}
			
		}

		return this.logs[this.numberOfVersions - 1].toString();
	
	}
	
	public String getRatingReport() {
		
		String ratingSummary = "";
		if(this.ratings[0] == -1) {
			
			return "No ratings submitted so far!";
			
		}
		
		double sumD = this.sum;
		double numberOfRatingsD = this.numberOfRatings;
		this.avg = sumD / numberOfRatingsD;
		double shift = Math.pow(10,1);
	    double avgD = Math.round(this.avg*shift)/shift;
	    avgString = String.valueOf(avgD);
	    
		ratingSummary = "Average of " + this.numberOfRatings + " ratings: " + 
				avgD + " (Score 5: " + this.rating5 +
				", Score 4: " + this.rating4 + ", Score 3: " + this.rating3 + 
				", Score 2: " + this.rating2 + ", Score 1: " + this.rating1 + ")";
			
		return ratingSummary;	
			
	}
	
	public String getAvg() {
		
		return avgString;
		
	}

	public int getNumberOfVersions() {
		
		return this.numberOfVersions;
		
	}
	public void setNumberOfRatings(int numberOfRatings) {
		
		this.maxRating = numberOfRatings;
		
	}
	
	public void setVersionInfo(String versionInfo) {
		
		this.versionInfo = versionInfo;
		
	}
	
	public void releaseUpdate(String versionNum) {
		
		this.numberOfVersions++;
		logs[this.numberOfVersions - 1] = new Log(versionNum);
		this.versionInfo = versionNum;		
		
	}
	
	public void submitRating(int rating) {
		
		this.numberOfRatings++;
		this.ratings[this.numberOfRatings - 1] = rating;		
		this.sum += rating;
		
		if(rating == 1) {
			
			this.rating1++;
			
		}
		
		if(rating == 2) {
			
			rating2++;
			
		}
		
		if(rating == 3) {
			
			this.rating3++;
			
		}
		
		if(rating == 4) {
			
			this.rating4++;
			
		}
		
		if(rating == 5) {
			
			this.rating5++;
			
		}
		
	}
	
	/*----------------------------------------------------------------------------------*/
	
	public String toString() {
		
		String s = "";	
		
		if(this.getRatingReport() == "No ratings submitted so far!") {
			
			s += this.name + " (Current Version: " + this.getCurrentVersion() + "; Average Rating: n/a)";
			
		}else {
			
			s += this.name + " (Current Version: " + this.getVersionInfo(getCurrentVersion()).toString() + "; Average Rating: " + this.getAvg() + ")";
			
		}
		
		
		return s;
		
	}
	
}
