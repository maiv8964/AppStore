package model;

import java.util.Arrays;

public class Log {

	private String version;
	private int numberOfFixes;
	private String[] fixes = new String[10];
	private String newestUpdate;
	
	public Log(String version) {
		
		this.version = version;
		this.newestUpdate = "";
		
	}
	
	public Log() {
		
		this.newestUpdate = "n/a";
		
	}
	
	public String getVersion() {
		
		return this.version;
		
	}
	
	public int getNumberOfFixes() {
		
		return this.numberOfFixes;
		
	}
	
	public String getFixes() {
		
		int count = 0;
		int[] indices = new int[this.numberOfFixes];
		
		for(int i = 0; i < this.numberOfFixes; i++) {
			
			if(this.fixes[i] != null) {
				
				indices[count] = i;
				count++;
				
			}
						
		}
		
		String[] fixesNoNull = new String[count];
		
		for(int i = 0; i < count; i++) {
			
			fixesNoNull[i] = this.fixes[indices[i]];
			
		}
		
		return Arrays.toString(fixesNoNull);
		
	}
	
	public Log[] getFixesArray() {
		
		int count = 0;
		int[] indices = new int[this.numberOfFixes];
		
		for(int i = 0; i < this.numberOfFixes; i++) {
			
			if(this.fixes[i] != null) {
				
				indices[count] = i;
				count++;
				
			}
						
		}
		
		String[] fixesNoNull = new String[count];
		
		for(int i = 0; i < count; i++) {
			
			fixesNoNull[i] = this.fixes[indices[i]];
			
		}	
		
		Log[] fixesNoNullLog = new Log[count];
		
		for(int i = 0; i < count; i++) {
			
			fixesNoNullLog[i] = new Log(fixesNoNull[i]); // make a log out of string
			
		}

		return fixesNoNullLog;
		
	}
	
	public String getNewestUpdate() {
		
		return this.newestUpdate;	
		
	}
	
	public void setVersion(String version) {
		
		this.version = version;
		
	}
	
	public void setNumberOfFixes(int NumberOfFixes) {
		
		this.numberOfFixes = NumberOfFixes; 
		
	}
	
	public void addFix(String fix) {
		
		this.numberOfFixes++;
		
		this.newestUpdate = fix;
		
		this.fixes[this.numberOfFixes - 1] = fix;
		
	}
	
	public String toString() {
		
		String s = "";		
		String fix = this.getFixes();
		
		s += "Version " + this.version + " contains " + this.numberOfFixes + " fixes " + fix;
		
		return s;
		
	}
		
}
